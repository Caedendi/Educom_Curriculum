<?php
function showBodyEnd() {
  echo "
    </body>
  ";
}
?>
