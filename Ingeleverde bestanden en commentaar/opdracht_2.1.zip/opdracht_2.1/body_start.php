<?php
function showBodyStart() {
  echo '
    <body>
  ';
}
?>
