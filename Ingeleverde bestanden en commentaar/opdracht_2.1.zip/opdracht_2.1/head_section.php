<?php
function showHeadSection() {
  echo '
  <head>
    <title>Opdracht 2.1.php</title>
    <link rel="stylesheet" type="text/css" href="./css/FirstExternalSheet.css">
  </head>
  ';
}
?>
