<?php
function showHeader($page) {
  echo '
    <h1 class="header">'. ucfirst($page) . '</h1>
  ';
}
?>
