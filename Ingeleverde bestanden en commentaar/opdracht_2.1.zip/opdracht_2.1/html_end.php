<?php
function showHtmlEnd() {
  echo '
    </html>
  ';
}
?>
