<?php
function showStartHtml() {
  echo '
  <!DOCTYPE html>
    <html>
  ';
}
?>
