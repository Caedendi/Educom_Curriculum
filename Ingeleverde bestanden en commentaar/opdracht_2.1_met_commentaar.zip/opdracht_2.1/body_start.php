<?php /* JH: Dit soort functies kan je beter verzamelen in een file (bijv. html.php) */
function showBodyStart() { 
  echo '
    <body>
  '; /* JH: Moet de <div class="mainbody"> is ook voor iedere pagina hetzelfde en kan hier ook bij */
}
?>
