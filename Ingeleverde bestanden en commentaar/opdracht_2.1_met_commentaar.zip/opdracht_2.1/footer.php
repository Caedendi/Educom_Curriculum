<?php /* JH: Dit soort functies kan je beter verzamelen in een file (bijv. html.php) */
function showFooter() {
  echo '
  <footer>
    <section>
      <p>&copy; 2019 Bart Commandeur</p>
    </section>
  </footer>
  ';
}
?>
