<?php /* JH: Dit soort functies kan je beter verzamelen in een file (bijv. html.php) */
function showHeadSection() {
  echo '
  <head>
    <title>Opdracht 2.1.php</title>
    <link rel="stylesheet" type="text/css" href="./css/FirstExternalSheet.css">
  </head>
  ';
}
?>
