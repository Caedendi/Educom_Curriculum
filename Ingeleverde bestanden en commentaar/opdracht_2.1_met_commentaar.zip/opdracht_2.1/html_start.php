<?php /* JH: Dit soort functies kan je beter verzamelen in een file (bijv. html.php) */
function showStartHtml() {
  echo '
  <!DOCTYPE html>
    <html>
  ';
}
?>
