<?php
function showFooter() {
  echo '
  <footer>
    <section>
      <p>&copy; 2019 Bart Commandeur</p>
    </section>
  </footer>
  ';
}
?>
