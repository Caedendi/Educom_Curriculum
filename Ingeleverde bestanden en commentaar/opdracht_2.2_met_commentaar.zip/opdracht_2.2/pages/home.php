<?php
function showHomeContent() {
  echo '
    <p>Welkom op de homepage voor Case 1.</p>
    <p>Deze website is geschreven als onderdeel van het traineeship Application/Software Development dat wordt aangeboden door Educom.</p>
    <p>Op elke pagina vind je links naar de pagina\'s waaruit deze website bestaat. Op de contactpagina kun je contact met mij opnemen. Op de aboutpagina vind je wat informatie over mijzelf.</p>
  ';
}
?>
