<?php
class DatabaseConnectionException extends Exception {};



?>
