<?php
function showTechnicalErrorContent() {
  echo '
    <h3>Ah oh! Er gaat ergens iets mis.</h3>
    <p>Er is bij ons een technisch probleem opgetreden. Probeer het later nog eens, of neem contact op met de beheerder van deze website.</p>
  ';
}
?>
