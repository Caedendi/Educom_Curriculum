<?php
/* Zie opmerking in debug.php */
$DEBUG = false;

if ($DEBUG) {
  define("DEBUG_TEST_PAGE", true);

}
else {
  define("DEBUG_TEST_PAGE", false);

}

?>
