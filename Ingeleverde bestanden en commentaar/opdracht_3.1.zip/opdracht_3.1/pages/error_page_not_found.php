<?php
function showError_Page_Not_FoundContent($data) {
  echo '
    <h3>Ah oh! Er gaat ergens iets mis.</h3>
    <p>De gekozen pagina kan niet worden gevonden.</p>
    <p>Als dit probleem zich voor blijft doen, verzoeken wij u om contact met ons op te nemen zodat wij dit probleem kunnen verhelpen.</p>
    <p>Onze excuses voor het ongemak.</p>
  ';
}
?>
