<?php
require_once "_test_definitions.php";
include_once PROJECT_ROOT . "pages\html_doc.php";

$view = new HtmlDoc();
$view->show();
?>
