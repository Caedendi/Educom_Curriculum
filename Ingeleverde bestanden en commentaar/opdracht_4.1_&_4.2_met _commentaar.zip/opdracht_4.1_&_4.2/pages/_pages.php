<?php /* JH: De \ in een "" heeft een speciale betekenis daarom moet je hem overal vervangen door \\, je kan beter de / gebruiken */
include_once PROJECT_ROOT . "pages\home_doc.php";
include_once PROJECT_ROOT . "pages\about_doc.php";
include_once PROJECT_ROOT . "pages\contact_doc.php";
include_once PROJECT_ROOT . "pages\contact_thanks_doc.php";
include_once PROJECT_ROOT . "pages\\register_doc.php"; 
include_once PROJECT_ROOT . "pages\login_doc.php";
include_once PROJECT_ROOT . "pages\webshop_doc.php";
include_once PROJECT_ROOT . "pages\details_doc.php";
include_once PROJECT_ROOT . "pages\cart_doc.php";
include_once PROJECT_ROOT . "pages\order_thanks_doc.php";
include_once PROJECT_ROOT . "pages\\error_page_not_found_doc.php";
include_once PROJECT_ROOT . "pages\\error_item_not_found_doc.php";
include_once PROJECT_ROOT . "pages\\error_technical_doc.php";
?>
